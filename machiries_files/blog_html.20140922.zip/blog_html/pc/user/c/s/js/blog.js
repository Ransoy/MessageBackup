
/*
* blog common javascript
*
*/

$(function(){
	// like button
	$(document).on('click', '.func_like', function(e){
		e.preventDefault();
		
		// execute like
		
	});

	$(document).on('click', 'a.disable', function(e){
		e.preventDefault();
	});
});
