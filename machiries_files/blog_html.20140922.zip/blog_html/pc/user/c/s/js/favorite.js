//=======================
//
//	Site:Macherie
//	Build:2007/4/1
//	Author:S.takaya
//
//=======================

//	ADD Favorite (ie,firefox,opera,netscape)
//=========================================

var Favo_url = "http://" + location.hostname + "/";
var Favo_name = "���C�u�`���b�g �}�V�F��";

//	Firefox
if(navigator.userAgent.indexOf("Firefox") > -1){
	document.write('<img src="/c/s/images/header/flower_favorite.gif" style="cursor:pointer;" onclick="window.sidebar.addPanel(\''+Favo_name+'\',\''+Favo_url+'\',\'\');"><br />');
	document.write('<a href="https://www.macherie.tv/registrationfree.php"><img src="/c/s/images/header/flower_regist.gif" alt="������!!�܂��͖����̌�" /></a>');
}
// IE
else if(navigator.userAgent.indexOf("MSIE") > -1){
	document.write('<img src="/c/s/images/header/flower_favorite.gif" style="cursor:pointer;" onclick="window.external.AddFavorite(\''+Favo_url+'\',\''+Favo_name+'\')"><br />');
	document.write('<a href="https://www.macherie.tv/registrationfree.php"><img src="/c/s/images/header/flower_regist.gif" alt="������!!�܂��͖����̌�" /></a>');
}
// Opera
else if(navigator.userAgent.indexOf("Opera") > -1){
	document.write('<a href="'+Favo_url+'" rel="sidebar" title="'+Favo_name+'"><img src="/c/s/images/header/flower_favorite.gif" alt="���C�ɓ���ɓo�^" /></a><br />');
	document.write('<a href="https://www.macherie.tv/registrationfree.php"><img src="/c/s/images/header/flower_regist.gif" alt="������!!�܂��͖����̌�" /></a>');
}

//	Netscape
else if(navigator.userAgent.indexOf("Netscape") > -1){
	document.write('<img src="/c/s/images/header/flower_favorite.gif" style="cursor:pointer;" onclick="window.sidebar.addPanel(\''+Favo_name+'\',\''+Favo_url+'\',\'\');"><br />');
	document.write('<a href="https://www.macherie.tv/registrationfree.php"><img src="/c/s/images/header/flower_regist.gif" alt="������!!�܂��͖����̌�" /></a>');
}
//	Google Chrome
else if(navigator.userAgent.indexOf("Chrome") > -1){
//	document.write('<a href="javascript:window.external.addFavorite(\''+Favo_url+'\',\''+Favo_name+'\')"><img src="/c/s/images/header/flower_favorite.gif" alt="���C�ɓ���ɓo�^" /></a><br />');
//	document.write('<a href="https://www.macherie.tv/registrationfree.php"><img src="/c/s/images/header/flower_regist.gif" alt="������!!�܂��͖����̌�" /></a>');
}

// Other
else{
	document.write('<a href="https://www.macherie.tv/registrationfree.php"><img src="/c/s/images/header/flower.gif" alt="������!!�܂��͖����̌�" /></a>');
}